#include<stdio.h>
#include<sys/mman.h>
#include<sys/stat.h>
#include<string.h>
#include<fcntl.h>

int main(){
     const int SIZE = 4096;
     const char * NAME = "PRODCON";
     int shm_fd;
     void * ptr;
     shm_fd = shm_open(NAME,O_CREAT|O_RDWR,0666);
     ptr = mmap(0,SIZE,PROT_READ,MAP_SHARED,shm_fd,0);
     printf("%s",(char*)ptr);
     shm_unlink(NAME);
}
