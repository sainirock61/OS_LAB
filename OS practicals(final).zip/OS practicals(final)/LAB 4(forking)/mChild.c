#include<stdio.h>
int main(){
     printf("\nChild Process running different program mChild");
}
