#include<stdio.h>
#include<unistd.h>
#include<sys/types.h>

//child process and parent process both executing the same program and same code
int main(){
     pid_t mpid = fork();
     if(mpid<0){
          fprintf(stderr,"\nFailed to fork child");
     }
     else{
          printf("Process says Hello World\n");
     }
}
