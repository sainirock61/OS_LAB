// Parent process forks the child process and waits for the child process to end

#include<stdio.h>
#include<unistd.h>
#include<sys/wait.h>
#include<sys/types.h>

int main(){
     pid_t mpid = fork();
     if(mpid<0){
          fprintf(stderr, "%s\n","Failed to fork child");
          return 1;
     }
     else if(mpid == 0){
          if(execlp("./mchild","./mchild",NULL) == -1){
               fprintf(stderr, "%s\n","Failed execlp" );
          }
     }
     else{
          wait(NULL);
          printf("\nChild Process Finished");
          printf("\nParent:Hello World! ");
     }
     return 0;
}
