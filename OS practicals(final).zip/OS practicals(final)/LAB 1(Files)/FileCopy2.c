#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include"Getline.c"
int main(int argc,char * argv[]){
	   int i;
    char * mode="w";
    char inFileName[100];
    char outFileName[100];
    for(i=1;i<argc;i++){
    	printf("argv[%d]=%s \n",i,argv[i]);

    	if(strcmp(argv[i],"-i")==0){
    		strcpy(inFileName,argv[++i]);
    	}
    	else if(strcmp(argv[i],"-o")==0){
    		if(argv[i+1][0]!='-'){
    				strcpy(outFileName,argv[++i]);
    		}
    		else{
    			printf("\n-i flag requires an argument");
    			exit(-1);
    		}
    	}
    	else if(strcmp(argv[i],"-a")==0){
    		mode="a";
    	}
    	else if(strcmp(argv[i],"-w")==0){
    		mode="w";
    	}

    }

    printf("\nMode:%s Input File:%s Output File:%s",mode,inFileName,outFileName);
    FILE * fptr1;
    FILE * fptr2;
    //printf("\nEnter the name of the file to be copied:");
    //char path[100];
    //scanf("%s",path);
    fptr1=fopen(inFileName,"r");
    if(fptr1==NULL){
        printf("\nError opening file.");
        exit(1);
    }
    //printf("\nEnter the name of the receiving file:");
    //scanf("%s",path);
    fptr2=fopen(outFileName,mode);
    char str[100];
    while(!feof(fptr1)){
      getLine(fptr1,str);
      fprintf(fptr2,"%s",str);
 	    fprintf(fptr2,"%s","\n");
    }
    printf("\nFile Copied Succesfully");
    fclose(fptr1);
    fclose(fptr2);
    return 0;
}
