#include<stdio.h>
#include<stdlib.h>
int main(int argc,char**argv){
     if(argc<2){
          printf("\nNot enough arguments");
          return 1;
     }

     FILE *fptr;
     fptr=fopen(argv[1],"r");
     if(fptr == NULL)
     {
       printf("Error!");
       exit(1);
     }
     char sentence[1000];
     fscanf(fptr,"%[^\n]",sentence);
     printf("%s",sentence);
     fclose(fptr);
     return 0;
}
