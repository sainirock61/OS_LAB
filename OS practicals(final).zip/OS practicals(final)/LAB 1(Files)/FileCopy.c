#include<stdio.h>
#include<stdlib.h>
#include"Getline.c"
int main(){
    int opt;
    FILE * fptr1;
    FILE * fptr2;
    printf("\nEnter the name of the file to be copied:");
    char path[100];
    scanf("%s",path);
    fptr1=fopen(path,"r");
    if(fptr1==NULL){
        printf("\nError opening file.");
        exit(1);
    }
    printf("\nEnter the name of the receiving file:");
    scanf("%s",path);
    fptr2=fopen(path,"w");
    char str[100];
    while(!feof(fptr1)){
    	getLine(fptr1,str);
    	fprintf(fptr2,"%s",str);
 		fprintf(fptr2,"%s","\n");
    }
    printf("\nFile Copied Succesfully");
    fclose(fptr1);
    fclose(fptr2);
    return 0;
}
