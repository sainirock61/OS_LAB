// Round robin Scheduling

#include<stdio.h>

#define MAX_PROCESSES 30
#define TIME_QUANTUM 3



struct Process{
    int pid;
    int burstTime;
    int arrivalTime;
    int waitingTime;
    int readyTime;
};
struct Queue{
    int Q[MAX_PROCESSES];
    int front;
    int rear;
    
};

void enqueue(struct Queue * q,int procNo){
    q->rear++;
    q->Q[q->rear] = procNo; 
}
int dequeue(struct Queue * q){
    int el = q->Q[q->front];
    for(int i = 0;i<q->rear;i++){
        q->Q[i] = q->Q[i+1];
    }
    q->rear--;
    return el;
}
void printQ(struct Queue q){
    for(int i=q.front;i<q.rear+1;i++)
        printf("%d ",q.Q[i]);
}
void printDetails(struct Process p[],int n){
    printf("\nID \tAT \tBT \tWT ");
    for(int i=0;i<n;i++){
        printf("\n%d \t%d \t%d \t%d",p[i].pid,p[i].arrivalTime,p[i].burstTime,p[i].waitingTime);
    }
}
int main(){
    struct Process p[MAX_PROCESSES];
    int n,i,timer,totalTime=0,remainingTime[MAX_PROCESSES];
    printf("\nEnter the number of processes:");
    scanf("%d",&n);
    
    printf("\nEnter the burst times:");
    for(i=0;i<n;i++){
        int bt;
        scanf("%d",&bt);
        p[i].burstTime = bt;
        totalTime+=bt;
        p[i].pid = i+1;
        remainingTime[i]=bt;
        p[i].readyTime=0;
        p[i].waitingTime = 0;
    }
    printf("\nEnter the arrival times:");
    for(i=0;i<n;i++){
        int at;
        scanf("%d",&at);
        p[i].arrivalTime = at;
    }
    timer=0;
    struct Queue queue;
    queue.front=0;
    queue.rear=-1;
    
    while(timer<totalTime){
        // Find all readyTime processes
        for(i=0;i<n;i++){
            if(p[i].arrivalTime==timer){
                enqueue(&queue,i);
                p[i].readyTime = 1;
            }
        }
        
        // Get next process in the queue
        int pi = dequeue(&queue);

        //Check whether the process terminates before time quantum
        int execTime;
        if(remainingTime[pi]<TIME_QUANTUM)
            execTime=remainingTime[pi];
        else
            execTime=TIME_QUANTUM;

        //Increment the wait times
        for(i=0;i<n;i++){
            if(p[i].readyTime){
                if(remainingTime[i]>0 && i!=pi){
                    p[i].waitingTime+=execTime;
                }
            }
        }
        printf("\nTimer=%d Executed process:%d,Execution time: %d",timer,p[pi].pid,execTime);
        remainingTime[pi]-=execTime;
        if(remainingTime[pi]>0){
            enqueue(&queue,p);
        }
        timer+=execTime;
    }

    printDetails(p,n);
    
}