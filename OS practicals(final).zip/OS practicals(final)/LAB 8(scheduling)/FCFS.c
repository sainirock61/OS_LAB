#include<stdio.h>
 
int main()
{
    int totalProcesses,burstTime[20],waitingTime[20],turnaroundTime[20],averageWait=0,averageTurnaroundTime=0,i,j;
    printf("Enter total number of processes(maximum 20):");
    scanf("%d",&totalProcesses);
 
    printf("\nEnter Process Burst Time\n");
    for(i=0;i<totalProcesses;i++)
    {
        printf("P[%d]:",i+1);
        scanf("%d",&burstTime[i]);
    }
 
    waitingTime[0]=0;    //waiting time for first process is 0
 
    //calculating waiting time
    for(i=1;i<totalProcesses;i++)
    {
        waitingTime[i]=0;
        for(j=0;j<i;j++)
            waitingTime[i]+=burstTime[j];
    }
 
    printf("\nProcess\t\tBurst Time\tWaiting Time\tTurnaround Time");
 
    										//calculating turnaround time
    for(i=0;i<totalProcesses;i++)
	{
        turnaroundTime[i]=burstTime[i]+waitingTime[i];
        averageWait+=waitingTime[i];
        averageTurnaroundTime+=turnaroundTime[i];
        printf("\nP[%d]\t\t%d\t\t%d\t\t%d",i+1,burstTime[i],waitingTime[i],turnaroundTime[i]);
    }
 
    averageWait=averageWait/totalProcesses;
    averageTurnaroundTime=averageTurnaroundTime/totalProcesses;
    printf("\n\nAverage Waiting Time:%d",averageWait);
    printf("\nAverage Turnaround Time:%d",averageTurnaroundTime);
 
    return 0;
}
