#include<stdio.h>
void Bsort(int mblock[],int m)
{
    int temp;
    for(int i=0;i<m-1;i++)
    {
        for(int j=0;j<m-1-i;j++)
        {
            if(mblock[j]>mblock[j+1])
            {
                temp=mblock[j];
                mblock[j]=mblock[j+1];
                mblock[j+1]=temp;
            }
        }
    }
}

void print(int mblock[],int m)
{
    for(int i=0;i<m;i++)
    {
        printf("%d",mblock[i]);
        printf("\n");
    }
}

void BestFit(int process[], int mblock[], int p, int m)
{
    int i, j;
    for (i = 0; i < p; i++)
    {
        Bsort(mblock, m);
        for (j = 0; j < m; j++)
        {
            if (mblock[j] >= process[i])
            {
                mblock[j] -= process[i];
                printf("Allocating process %d to memory %d\n Size remaining in it after allocation %d\n\n", i + 1, j + 1, mblock[j]);
                process[i] = 9999;
                break;
            }
        }
    }
    for (j = 0; j < m; j++)
    {
        if (process[j] != 9999)
        {
            printf("The Process %d is not allocated\n", j);
        }
    }
}
int main()
{
    /*int ar[8]={ 5,9,2,3,6,7,8,0};
    Bsort(ar,8);
    print(ar,8);*/
    int p, m;
    printf("Enter number of processes:");
    scanf("%d", &p);
    printf("Enter number of Memory blocks:");
    scanf("%d", &m);
    int process[p], mblock[m], i;
    for (i = 0; i < p; i++)
    {
        printf("Enter size of process %d:", i + 1);
        scanf("%d", &process[i]);
    }
    for (i = 0; i < m; i++)
    {
        printf("Enter size of memory %d:", i + 1);
        scanf("%d", &mblock[i]);
    }

    BestFit(process, mblock, p, m);

    return 0;
}