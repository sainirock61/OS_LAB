#include<pthread.h>
#include<stdio.h>

static long sum=0;
void *runner(void *param1);

int main(int argc, char *argv[]){
pthread_t tid1,tid2;
pthread_attr_t attr1,attr2;

if(argc!=3){
fprintf(stderr,"usage: a.out<integer value>\n");
return -1;
}
if(atoi(argv[1])<0){
fprintf(stderr,"%d must be >= 0\n",atoi(argv[1]));
return -1;
}
if(atoi(argv[2])<0){
fprintf(stderr,"%d must be >= 0\n",atoi(argv[2]));
return -1;

}

pthread_attr_init(&attr1);
pthread_attr_init(&attr2);
pthread_create(&tid1,&attr1,runner,argv[1]); //creating thread 1
pthread_create(&tid2,&attr2,runner,argv[2]); //creating thread 2
pthread_join(tid1,NULL);
pthread_join(tid2,NULL);
printf("sum= %d\n",sum);
}

void *runner(void *param)
{
int upper=atoi(param);
sum+=upper;
pthread_exit(0);
}